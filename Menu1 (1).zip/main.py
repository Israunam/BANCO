from Fraccion import*
from Menu import*
import matplotlib.pyplot as plt

class Pruebas:
  menu = Menu() 
  menu.bienvenida()
  menu.pantallaDeOperaciones()
  menu.operar()
  menu.menuIterativo()
  #print(menu.frecuencia)
  menu.graficar()

