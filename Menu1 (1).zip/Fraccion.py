class Fraccion:
  # init es un metodo que nos da los valores iniciales para la clase.
  def __init__(self, num, den):
    self.num = num
#es el atributo-----Como se reconoce
    self.den = den

def mostrar(self):
  print(self.num, "/" , self.den)

# La difere4nbciA ENTRE ESTOS DOS es que el de arriba solo imprime
# el de abajo regresa una cadenacon la que podemos hacer mas cosas
 
def regresa(self):
  return str(self.num) + "/" + str(self.den)
# fracc1 = Fraccion (3,5)
# cadena = str(fraqccion1)

def sumar(self, fraccion):
  nueNum = self.num * fraccion.den + fraccion.num * self.den
  nueDen = self.den * fraccion.den
  return Fraccion(nueNum, nueDen)
  
def restar(self, fraccion):
  nueNum = self.num * fraccion.den - fraccion.num * self.den
  nueDen = self.den * fraccion.den
  return Fraccion(nueNum, nueDen)
  
def multiplicar(self, fraccion):
  nueNum = self.num * fraccion.num
  nueDen = self.num * fraccion.den
  return Fraccion(nueNum, nueDen)

def dividir(self, fraccion):
  nueNum = self.num * fraccion.den
  nueDen = self.den * fraccion.num  
  return Fraccion(nueNum, nueDen)
