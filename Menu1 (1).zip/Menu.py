from Fraccion import*
import matplotlib.pyplot as plt
class Menu:
  

  def __init__(self):
    self.f1 = None
    self.f2 = None
    self.opcion = ""
    self.lista = []
    self.frecuencia = [0,0,0,0]
  

  def bienvenida(self):
    print("Bienvenido")
    print("Eliga la opcion que desea:")
    print("a) Sumar fracciones")
    print("b) Restar fracciones")
    print("c) Multiplicar fracciones")
    print("d) Dividir fracciones")
    self.opcion = input()
    return self.opcion

  def pantallaDeOperaciones(self):
    print("Introduce dos fracciones:")
    n1 = int(input("Coloca el primer numerador: "))
    d1 = int(input("Coloca el primer denominador: "))
    n2 = int(input("Coloca el segundo numerador: "))
    d2 = int(input("Coloca el segundo denominador: "))
    self.f1 = Fraccion(n1,d1)
    self.f2 = Fraccion(n2,d2)
    #self.f1 = fraccion1
    #self.f2 = fraccion2
    #mostrar(self.f1)
    #mostrar(self.f2)
    return self.f1
    return self.f2
    
  def operar(self):
    fraccion1 = self.f1
    fraccion2 = self.f2
    if self.opcion == "a":
      fraccion3 = sumar(fraccion1,fraccion2)
      mostrar(fraccion1)
      print("+")
      mostrar(fraccion2)
      print("=")
      mostrar(fraccion3)
      a =  " " + regresa(fraccion3) + " "
      self.lista.append(a)
      self.frecuencia[0] = self.frecuencia[0] + 1 
      return fraccion3
      return self.lista
      return self.frecuencia
      
    elif self.opcion == "b":
      fraccion3 = restar(fraccion1, fraccion2)
      mostrar(fraccion1)
      print("-")
      mostrar(fraccion2)
      print("=")
      mostrar(fraccion3)
      a = " " + regresa(fraccion3) + " "
      self.lista.append(a) 
      self.frecuencia[1] = self.frecuencia[1] + 1
      return fraccion3
      return self.lista       
    
    elif self.opcion == "c":
      fraccion3 = multiplicar(fraccion1, fraccion2)
      mostrar(fraccion1)
      print("*")
      mostrar(fraccion2)
      print("=")
      mostrar(fraccion3)
      a = " "+ regresa(fraccion3) + " "
      self.lista.append(a)
      self.frecuencia[2] = self.frecuencia[2] + 1      
      return fraccion3   
      return self.lista

    elif self.opcion == "d":
      fraccion3 = dividir(fraccion1, fraccion2)
      mostrar(fraccion1)
      print("/")
      mostrar(fraccion2)
      print("=")
      mostrar(fraccion3)
      a = " "+regresa(fraccion3) + " "
      self.lista.append(a) 
      self.frecuencia[3] = self.frecuencia[3] + 1           
      return fraccion3
      return self.lista
 
    else:
      print("opcion no valia")


  def __str__(self):
    
    if self.f1 == None:
      x = (" aun no se introducen ")
    else:
      a = regresa(self.f1)
      b = regresa(self.f2)
      x = (" son " + a + " y " + b)
    
    if self.opcion == "":
      y = ("aun no ha sido elegida opcion el usuario")
    else:
      if self.opcion == "a":
        z = "una suma"
      elif self.opcion == "b":
        z = "una resta"
      elif self.opcion == "c":
        z = "una multiplicacion"
      elif self.opcion == "d":
        z = "una division"
      else:
        z = "no valida"   
      y = ("elegida fue " + z + "(" + str(self.opcion) + ")")
      q = "".join(self.lista)
      if q == "":
        o = "vacia"
      else:
        o = q
    return("Las fracciones" + x + " y la opcion " + y + " y la lista de resultados es " + o)

  def graficar(self):
    fig = plt.figure()
    ax = fig.add_subplot(111)
    datos = self.frecuencia
    xx = range(len(self.frecuencia))
    ax.bar(xx,self.frecuencia)
    plt.xlabel('Operaciones')
    plt.ylabel('Frecuencia de uso')
    plt.xticks(range(len(datos)),('suma', 'resta', 'multiplicacion', 'division'), rotation=5)
    plt.show

  def menuIterativo(self):
    a = True
    while a:
      b = input("¿Desea realizar otra operacion? teclee si/no: ")
      if b == "si":
        self.bienvenida()
        self.pantallaDeOperaciones()
        self.operar()
      elif b == "no":
        a = False
      else:
        print("opcion no valida")
    print("Hasta Luego!")
    

